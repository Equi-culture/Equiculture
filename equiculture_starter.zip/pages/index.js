import Layout from "@/components/Layout";
import CreatePost from "@/components/CreatePost";
import FeedPost from "@/components/FeedPost";

export default function HomePage() {
  return (
    <Layout>
      <CreatePost />
      <FeedPost user="@Reiterin123" time="vor 2 Std." text="Heute ein super Training gehabt! Mein Wallach war richtig motiviert 💪🐴" image="/demo-post.jpg" />
      <FeedPost user="@WesternRider" time="gestern" text="Neue Turniersaison gestartet – freut ihr euch auch schon?" image="/demo-post2.jpg" />
    </Layout>
  );
}
