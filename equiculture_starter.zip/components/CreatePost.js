import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export default function CreatePost() {
  return (
    <Card className="bg-[#2E4F3D] border border-gold/20 shadow-xl mb-6">
      <CardContent className="p-4">
        <h2 className="text-lg font-semibold mb-2 text-gold">Beitrag erstellen</h2>
        <Textarea className="mb-2 bg-[#1F3A30] text-white placeholder:text-gold/50" placeholder="Was möchtest du teilen?" />
        <div className="flex justify-end">
          <Button className="bg-gold text-[#1F3A30] font-bold hover:opacity-90">Veröffentlichen</Button>
        </div>
      </CardContent>
    </Card>
  );
}
