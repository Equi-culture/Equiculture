import { Avatar } from "@/components/ui/avatar";
import { Bell, Search } from "lucide-react";

export default function Header() {
  return (
    <header className="flex items-center justify-between px-6 py-4 border-b border-gold/30 bg-[#1F3A30] shadow-md">
      <h1 className="text-2xl font-serif text-gold">EquiCulture</h1>
      <div className="flex items-center gap-4">
        <Search className="w-5 h-5 text-gold" />
        <Bell className="w-5 h-5 text-gold" />
        <Avatar className="w-8 h-8 border-2 border-gold" />
      </div>
    </header>
  );
}
