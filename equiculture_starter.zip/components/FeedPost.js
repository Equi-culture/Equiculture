import { Card, CardContent } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";

export default function FeedPost({ user, time, text, image }) {
  return (
    <Card className="bg-[#2E4F3D] border border-gold/20 shadow-md mb-4">
      <CardContent className="p-4">
        <div className="flex items-center gap-3 mb-2">
          <Avatar className="w-8 h-8 border border-gold" />
          <div>
            <p className="font-semibold text-gold">{user}</p>
            <p className="text-sm text-gold/70">{time}</p>
          </div>
        </div>
        <p className="text-white mb-2">{text}</p>
        {image && <img src={image} alt="Post" className="rounded-xl border border-gold/30" />}
      </CardContent>
    </Card>
  );
}
