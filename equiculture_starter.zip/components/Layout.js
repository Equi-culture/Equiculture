import Header from "./Header";

export default function Layout({ children }) {
  return (
    <div className="min-h-screen bg-[#1F3A30] text-white font-sans">
      <Header />
      <main className="p-6 max-w-6xl mx-auto">{children}</main>
    </div>
  );
}
